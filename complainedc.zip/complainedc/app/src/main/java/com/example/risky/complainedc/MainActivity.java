package com.example.risky.complainedc;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;


public class MainActivity extends AppCompatActivity {

    WebView webviewku;
    WebSettings websettingku;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webviewku = findViewById(R.id.WebView1);
        webviewku.setWebViewClient( new WebViewClient());
        webviewku.loadUrl("https://docs.google.com/forms/d/e/1FAIpQLSdZwGAb8hcfwgun9PVr6hMzcbpAcEZqHG4Gv0MdKlyDvb6SGg/viewform");
        WebSettings webSettings = webviewku.getSettings();
        webSettings.setJavaScriptEnabled(true);

    }
    @Override
    public void onBackPressed() {
        if(webviewku.canGoBack()){
            webviewku.goBack();
        }   else {
            super.onBackPressed();
        }
    }
    
}
